# Smart Attendance SaaS

## Overview
Multi-company Smart Attendance Enterprise SaaS for corporate organizations and educational institutions. Supports two modes: Corporate (Manager/Employee) and Academic (Lecturer/Student). Features JWT authentication, role-based access, multi-tenant company isolation, attendance tracking with QR codes and BLE proximity, Zoom meeting management, quizzes, PDF reports, and subscription management with 14-day free trial.

## Project Architecture
```
src/
├── config/
│   └── db.js                  # MongoDB connection
├── controllers/
│   ├── authController.js      # Register, login, logout, profile
│   ├── userController.js      # User CRUD operations
│   ├── attendanceController.js # Sessions + attendance records
│   ├── courseController.js    # Course management (academic)
│   ├── quizController.js      # Quiz creation/submission (academic)
│   ├── zoomController.js      # Zoom meeting management
│   ├── paymentController.js   # Stripe + Paystack subscriptions
│   └── reportController.js    # PDF report generation
├── middleware/
│   ├── auth.js                # JWT authentication
│   ├── role.js                # Role-based access + mode isolation
│   ├── companyIsolation.js    # Multi-tenant company scoping
│   ├── deviceValidation.js    # Device tracking + 6-hour lockout
│   └── subscription.js        # Subscription/trial gating
├── models/
│   ├── User.js                # User (email or indexNumber login)
│   ├── Company.js             # Company with mode + subscription
│   ├── AttendanceSession.js   # Attendance sessions
│   ├── AttendanceRecord.js    # Per-user attendance check-ins
│   ├── QrToken.js             # QR tokens with 6-digit codes
│   ├── Course.js              # Academic courses
│   ├── Quiz.js                # Academic quizzes
│   ├── QuizSubmission.js      # Student quiz submissions
│   └── ZoomMeeting.js         # Zoom meeting scheduling
├── routes/
│   ├── auth.js                # Auth routes
│   ├── users.js               # User management routes
│   ├── attendanceSessions.js  # Attendance session + record routes
│   ├── qrTokens.js            # QR token routes
│   ├── courses.js             # Course routes (academic only)
│   ├── quizzes.js             # Quiz routes (academic only)
│   ├── zoom.js                # Zoom meeting routes
│   ├── payments.js            # Payment/subscription routes
│   └── reports.js             # PDF report routes
├── ble/
│   ├── index.js               # BLE module entry point
│   ├── constants.js           # BLE UUIDs, RSSI thresholds
│   ├── broadcastFormat.js     # Encode/decode broadcast payloads
│   ├── broadcaster.js         # BLE advertising (manager device)
│   └── scanner.js             # BLE scanning with RSSI validation
├── public/
│   ├── index.html             # Web dashboard SPA
│   ├── css/style.css          # Dashboard styles
│   └── js/app.js              # Dashboard JavaScript
├── utils/
│   └── jwt.js                 # JWT token generation/verification
└── server.js                  # Main entry point
```

## System Modes
- **Corporate**: Manager + Employee roles. Work sessions, meetings, reports.
- **Academic**: Lecturer + Student roles. Courses, quizzes, sessions, meetings, reports.
- Mode set at company creation. Roles enforced per mode.

## User Roles
| Role | Login | Mode | Can Manage |
|------|-------|------|------------|
| superadmin | Email | Both | Everything |
| admin | Email | Both | Company-level |
| manager | Email | Corporate | Employees, sessions, meetings, reports |
| employee | Email | Corporate | View attendance, join meetings |
| lecturer | Email | Academic | Courses, students, quizzes, sessions, meetings |
| student | Index Number | Academic | Take quizzes, mark attendance, join meetings |

## Key Decisions
- **Roles**: superadmin, admin, manager, employee, lecturer, student
- **Company Isolation**: All queries scoped to user's company (superadmin bypasses)
- **Mode Isolation**: Academic routes (courses/quizzes) require academic mode
- **Soft Delete**: Users deactivated, not deleted
- **Password**: bcrypt with 12 salt rounds, min 8 characters
- **JWT**: Bearer token authentication
- **Device Tracking**: deviceId stored on User, validated on sensitive actions
- **6-Hour Restriction**: After logout, cannot sign in to a different account for 6 hours
- **Subscription**: Company-level, 14-day free trial with countdown timer
- **Pricing**: Stripe $11/mo, Paystack GHS 120/mo, 20% annual discount

## Environment Variables
- `MONGODB_URI` - MongoDB connection string (secret)
- `JWT_SECRET` - JWT signing secret (env var)
- `JWT_EXPIRES_IN` - Token expiry (default: 7d)
- `PORT` - Server port (default: 5000)

## API Endpoints

### Auth
- `POST /api/auth/register` - Register (creates company + first manager/lecturer)
- `POST /api/auth/login` - Login (email or indexNumber + password)
- `POST /api/auth/logout` - Logout (6-hour restriction)
- `GET /api/auth/me` - Current user profile + trial/subscription status

### Users
- `GET /api/users` - List users (filtered by company)
- `POST /api/users` - Create user (manager+ creates employees, lecturer+ creates students)
- `PATCH /api/users/:id` - Update user
- `DELETE /api/users/:id` - Deactivate user

### Attendance Sessions
- `POST /api/attendance-sessions/start` - Start session (manager/lecturer+)
- `POST /api/attendance-sessions/:id/stop` - Stop session
- `GET /api/attendance-sessions` - List sessions
- `GET /api/attendance-sessions/active` - Get active session
- `GET /api/attendance-sessions/:id` - Get session with records
- `POST /api/attendance-sessions/mark` - Mark attendance (with QR code/manual)
- `GET /api/attendance-sessions/my-attendance` - Personal attendance history

### QR Tokens
- `POST /api/qr-tokens/generate` - Generate QR token with 6-digit code
- `POST /api/qr-tokens/validate` - Validate QR token
- `GET /api/qr-tokens/session/:sessionId` - List tokens for session

### Courses (Academic Only)
- `POST /api/courses` - Create course (lecturer+)
- `GET /api/courses` - List courses
- `GET /api/courses/:id` - Get course details
- `PATCH /api/courses/:id` - Update course
- `POST /api/courses/:id/enroll` - Enroll students
- `DELETE /api/courses/:id/students/:studentId` - Remove student

### Quizzes (Academic Only)
- `POST /api/quizzes` - Create quiz (lecturer+)
- `GET /api/quizzes` - List quizzes
- `GET /api/quizzes/:id` - Get quiz (correct answers hidden from students)
- `POST /api/quizzes/:id/submit` - Submit quiz (students only)

### Zoom Meetings
- `POST /api/zoom` - Create meeting (manager/lecturer+)
- `GET /api/zoom` - List meetings
- `GET /api/zoom/:id` - Get meeting details
- `POST /api/zoom/:id/join` - Join meeting
- `POST /api/zoom/:id/cancel` - Cancel meeting

### Payments
- `GET /api/payments/plans` - List plans (public)
- `GET /api/payments/status` - Subscription + trial status
- `POST /api/payments/subscribe` - Subscribe (admin/manager/lecturer+)
- `POST /api/payments/cancel` - Cancel subscription
- `POST /api/payments/webhook/stripe` - Stripe webhook (public)
- `POST /api/payments/webhook/paystack` - Paystack webhook (public)

### Reports
- `GET /api/reports/attendance` - Attendance PDF report
- `GET /api/reports/sessions` - Sessions PDF report
- `GET /api/reports/performance` - Performance/quiz PDF report (academic)

## Recent Changes
- 2026-02-18: Separate Employee Portal with self-registration. Landing page now shows 3 portals (Staff, Employee, Student). Employee portal has green theme, own sign-up (email + company name), login flows. Employee login scoped by company for multi-tenant security. Auto-generated Employee IDs on registration. New API: POST /api/auth/register-employee.
- 2026-02-18: Separate Student Portal with self-registration. Landing page shows portal selector (Staff vs Student). Student portal has purple theme, own sign-up (index number + institution name), login, and forgot password flows. Student login scoped by company for multi-tenant security. New API: POST /api/auth/register-student.
- 2026-02-18: Added auto-generated Employee IDs (e.g., COM-EMP-0001) using atomic counter on Company model. Employee IDs shown in user table, employee dashboard. Manager modal simplified to only add employees, lecturer modal to only add students.
- 2026-02-18: Implemented distinct portal experiences per role with unique color themes, role-specific sidebar navigation, personalized dashboards with stats/quick actions, and portal-branded top bar
- 2026-02-18: Full rebuild with dual-mode support (corporate/academic), new models (Course, Quiz, QuizSubmission, AttendanceRecord, ZoomMeeting), controllers, web dashboard frontend, PDF reports, Stripe+Paystack pricing
- 2026-02-18: Added subscription middleware + payment routes
- 2026-02-18: Added deviceId tracking, lastLogoutTime, 6-hour login restriction
- 2026-02-18: Added BLE module (broadcast, scan, RSSI validation)
- 2026-02-18: Added QR token generation with 6-digit code and expiry
- 2026-02-18: Added attendance session feature (start/stop/list)
- 2026-02-18: Initial project setup with full auth system
