const Company = require("../models/Company");

const PRICING = {
  stripe: {
    monthly: 1100,
    annual: 10560,
    currency: "usd",
    label: { monthly: "$11/month", annual: "$105.60/year (20% off)" },
  },
  paystack: {
    monthly: 12000,
    annual: 115200,
    currency: "GHS",
    label: { monthly: "₵120/month", annual: "₵1,152/year (20% off)" },
  },
};

exports.getPlans = async (req, res) => {
  res.json({
    plans: [
      {
        id: "monthly",
        name: "Monthly",
        stripe: { amount: PRICING.stripe.monthly, currency: "usd", label: PRICING.stripe.label.monthly },
        paystack: { amount: PRICING.paystack.monthly, currency: "GHS", label: PRICING.paystack.label.monthly },
      },
      {
        id: "annual",
        name: "Annual (20% discount)",
        stripe: { amount: PRICING.stripe.annual, currency: "usd", label: PRICING.stripe.label.annual },
        paystack: { amount: PRICING.paystack.annual, currency: "GHS", label: PRICING.paystack.label.annual },
      },
    ],
  });
};

exports.getStatus = async (req, res) => {
  try {
    const company = await Company.findById(req.user.company);
    if (!company) {
      return res.status(404).json({ error: "Company not found" });
    }

    res.json({
      subscription: {
        active: company.subscriptionActive,
        plan: company.subscriptionPlan,
        provider: company.subscriptionProvider,
      },
      trial: {
        active: company.isTrialActive,
        daysRemaining: company.trialDaysRemaining,
        timeRemaining: company.trialTimeRemaining,
        startDate: company.trialStartDate,
        endDate: company.trialEndDate,
        used: company.trialUsed,
      },
      hasAccess: company.hasAccess,
    });
  } catch (error) {
    console.error("Payment status error:", error);
    res.status(500).json({ error: "Failed to fetch payment status" });
  }
};

exports.subscribe = async (req, res) => {
  try {
    const { plan, provider } = req.body;

    if (!plan || !["monthly", "annual"].includes(plan)) {
      return res.status(400).json({ error: "Valid plan is required (monthly or annual)" });
    }

    if (!provider || !["stripe", "paystack"].includes(provider)) {
      return res.status(400).json({ error: "Valid provider is required (stripe or paystack)" });
    }

    const company = await Company.findById(req.user.company);
    if (!company) {
      return res.status(404).json({ error: "Company not found" });
    }

    const pricing = PRICING[provider][plan];
    const currency = PRICING[provider].currency;

    // TODO: Integrate with actual payment provider
    // For Stripe: create checkout session
    // For Paystack: initialize transaction

    res.json({
      message: "Payment integration pending",
      plan,
      provider,
      amount: pricing,
      currency,
      label: PRICING[provider].label[plan],
      checkoutUrl: null,
      note: `Connect ${provider === "stripe" ? "Stripe" : "Paystack"} to enable subscriptions.`,
    });
  } catch (error) {
    console.error("Subscribe error:", error);
    res.status(500).json({ error: "Failed to initiate subscription" });
  }
};

exports.cancel = async (req, res) => {
  try {
    const company = await Company.findById(req.user.company);
    if (!company) {
      return res.status(404).json({ error: "Company not found" });
    }

    if (!company.subscriptionActive) {
      return res.status(400).json({ error: "No active subscription to cancel" });
    }

    // TODO: Integrate with payment provider to cancel

    res.json({
      message: "Payment integration pending",
      note: "Connect payment provider to process cancellation.",
    });
  } catch (error) {
    console.error("Cancel subscription error:", error);
    res.status(500).json({ error: "Failed to cancel subscription" });
  }
};

exports.stripeWebhook = async (req, res) => {
  try {
    // TODO: Verify Stripe signature and process events
    res.json({ received: true });
  } catch (error) {
    console.error("Stripe webhook error:", error);
    res.status(400).json({ error: "Webhook processing failed" });
  }
};

exports.paystackWebhook = async (req, res) => {
  try {
    // TODO: Verify Paystack signature and process events
    res.json({ received: true });
  } catch (error) {
    console.error("Paystack webhook error:", error);
    res.status(400).json({ error: "Webhook processing failed" });
  }
};
