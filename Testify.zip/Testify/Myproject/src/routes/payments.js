const express = require("express");
const authenticate = require("../middleware/auth");
const { requireRole } = require("../middleware/role");
const { companyIsolation } = require("../middleware/companyIsolation");
const paymentController = require("../controllers/paymentController");

const router = express.Router();

router.get("/plans", paymentController.getPlans);
router.post("/webhook/stripe", express.raw({ type: "application/json" }), paymentController.stripeWebhook);
router.post("/webhook/paystack", paymentController.paystackWebhook);

router.use(authenticate);

router.get("/status", companyIsolation, paymentController.getStatus);
router.post("/subscribe", requireRole("manager", "lecturer", "admin", "superadmin"), companyIsolation, paymentController.subscribe);
router.post("/cancel", requireRole("manager", "lecturer", "admin", "superadmin"), companyIsolation, paymentController.cancel);

module.exports = router;
