# Smart Attendance SaaS

## Overview
A multi-company Smart Attendance Enterprise SaaS platform designed for corporate organizations and educational institutions. The system supports two operational modes:

- **Corporate Mode**: Managers and Employees — manage work sessions, attendance, Zoom meetings, reports, and subscriptions.
- **Academic Mode**: Lecturers and Students — manage courses, attendance sessions, quizzes, Zoom meetings, and reports.

Key features include JWT-based authentication, multi-tenant company isolation, QR code and BLE-based attendance marking, device tracking with 6-hour logout lockout, subscription management (Stripe + Paystack), PDF report generation, and Zoom meeting scheduling.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Tech Stack
- **Runtime**: Node.js with Express 5
- **Database**: MongoDB via Mongoose ODM
- **Authentication**: JWT (jsonwebtoken + bcryptjs)
- **PDF Generation**: PDFKit
- **Security**: Helmet, CORS
- **Frontend**: Vanilla HTML/CSS/JS served as static files (no frontend framework)

### Project Structure
All source code lives under `Myproject/src/`. The application follows a standard MVC pattern:

```
Myproject/src/
├── config/db.js           # MongoDB connection setup
├── controllers/           # Business logic for each domain
├── middleware/             # Auth, roles, company isolation, device validation, subscription checks
├── models/                # Mongoose schemas and models
├── routes/                # Express route definitions
├── utils/jwt.js           # JWT token generation and verification
├── ble/                   # BLE (Bluetooth Low Energy) module for mobile attendance
├── public/                # Static frontend (HTML, CSS, JS)
└── server.js              # Express app setup and middleware registration
```

### Multi-Tenancy & Data Ownership
- Every data model includes a `company` field referencing the Company model
- The `companyIsolation` middleware automatically scopes all queries to the authenticated user's company
- Superadmin users bypass company scoping
- **Lecturer Isolation**: All lecturer-facing endpoints filter by `createdBy`/`lecturer` === logged-in user. Lecturers can only view, edit, generate QR for, open attendance, and view reports for their own classes/sessions. No cross-lecturer data visibility.
- **Student Isolation**: Students only see courses they are enrolled in, quizzes for those courses, and their own attendance/submission records. Cannot see other students' data.
- **Admin Access**: Full access to all lecturers, classes, attendance, and reports within their own institution only.
- **Per-Lecturer Active Sessions**: Multiple lecturers can run concurrent attendance sessions; each is scoped to the lecturer who created it.

### Authentication & Authorization
- Strict registration hierarchy: Admin creates institution -> Admin approves Lecturers/Employees -> Admin/Lecturer approves Students
- JWT tokens issued only on admin registration and login; non-admin registrations are pending approval (no token issued)
- `auth.js` middleware verifies tokens and attaches user to request
- `role.js` middleware provides role-based access control with a hierarchy: superadmin > admin > manager > lecturer > employee > student
- `isApproved` field enforced server-side at login — unapproved users cannot access the system
- Mode isolation ensures corporate roles can't access academic features and vice versa
- Device validation middleware tracks device IDs and enforces a 6-hour lockout after logout
- Institution code required for all non-admin registrations to prevent unauthorized institution creation
- **Student Roster Validation**: Students must be pre-registered in a class roster by their lecturer before they can register. Registration validates Student ID against the StudentRoster collection. If not found, registration is rejected. Validated students are auto-approved and auto-enrolled in their courses.

### Attendance System
- Managers/Lecturers create attendance sessions
- Employees/Students mark attendance via QR code scan, 6-digit code entry, BLE proximity, Jitsi join, or manual entry
- QR tokens are time-limited (default 5 minutes) with auto-expiry via MongoDB TTL index
- BLE module handles Bluetooth broadcasting and scanning for proximity-based attendance (designed for React Native mobile clients)

### Subscription & Billing
- 14-day free trial for new companies
- Subscription plans: Monthly and Annual (20% discount)
- Payment providers: Stripe (USD) and Paystack (GHS)
- Subscription middleware gates access to features — expired trials block usage
- Webhook endpoints for both Stripe and Paystack

### API Structure
All API routes are prefixed with `/api/`:
- `POST /api/auth/register` — Register admin + create institution (auto-generates institutionCode, qrSeed, bleLocationId)
- `POST /api/auth/register-lecturer` — Register lecturer with institution code (pending approval)
- `POST /api/auth/register-student` — Register student with institution code (pending approval)
- `POST /api/auth/register-employee` — Register employee with institution code (pending approval)
- `POST /api/auth/login` — Login (email or index number), enforces isApproved and subscription checks
- `POST /api/auth/migrate-orphans` — Superadmin only: migrate orphan users to default institution
- `/api/roster/:courseId/upload` — Lecturer uploads student list to course (POST array of {studentId, name})
- `/api/roster/:courseId` — View roster for a course
- `/api/approvals` — Admin approval management (pending, approve, reject)
- `/api/users` — User CRUD (company-scoped)
- `/api/attendance-sessions` — Session management + attendance marking (course validated against institution)
- `/api/qr-tokens` — QR token generation and validation
- `/api/courses` — Course management (academic mode only)
- `/api/quizzes` — Legacy quiz endpoints (academic mode only)
- `/api/lecturer/quizzes` — Lecturer quiz CRUD: create, list, update, delete quizzes + manage questions + view results
- `/api/student/quizzes` — Student quiz access: list available quizzes (time-window filtered by default, ?showAll=true for all), start attempt (shuffled questions), submit answers, view results. Auto-submits on tab switch
- `/api/admin/quizzes` — Admin read-only quiz access: list all quizzes, view details, all student attempts
- `/api/admin/quizzes/reports` — Admin quiz reports: totalQuizzes, participationRate, averageScore, quizzesPerLecturer
- `/api/zoom` — Jitsi meeting management (create, list, get, start, join, end, cancel, attendees). Uses meet.jit.si with auto-generated room names. Join records attendance automatically if linked to a session
- `/api/jitsi/create` — POST: Create Jitsi meeting (manager/lecturer only). Generates roomName (companyId_sessionId_hash), checks subscription/trial. Returns {meetingId, roomName, joinUrl}
- `/api/jitsi/end` — POST: End meeting (creator only). Sets endTime. Input: {meetingId}
- `/api/jitsi/join/:roomName` — GET: Join meeting (all roles). Validates companyId isolation. Returns {joinUrl}
- `/api/jitsi/attendance` — POST: Track attendance (all roles). Input: {meetingId, action: "join"|"leave"}. Stores userId, meetingId, action, timestamp
- `/api/admin/dashboard` — Admin: JSON dashboard stats (totalStudents, totalLecturers, totalClasses, totalSessions, averageAttendanceRate)
- `/api/admin/reports/charts` — Admin: JSON chart data (attendanceTrend by date, lecturerComparison, classPerformance). Supports date range filters (startDate, endDate)
- `/api/admin/reports/attendance` — Admin: Institution-wide attendance overview PDF with aggregated stats (totalStudents, totalClasses, totalSessions, averageAttendanceRate, totalPresent, totalAbsent), per-class breakdown table (classId, className, lecturerName, totalStudents, presentCount, absentCount, attendancePercentage), and individual records. Filters: lecturerId, classId, startDate, endDate
- `/api/admin/reports/sessions` — Admin: Session activity tracking PDF with per-session detail (sessionId, className, lecturerName, startTime, endTime, duration in minutes, totalStudents, presentCount), suspicious session flagging (duration < 5 min), and summary stats. Filters: lecturerId, classId, startDate, endDate
- `/api/admin/reports/performance` — Admin: Quiz/academic performance PDF with per-course breakdown (avgScore, highestScore, lowestScore, passRate), individual submissions, and aggregate stats. Filters: lecturerId, classId, startDate, endDate
- `/api/admin/reports/lecturers` — Admin: Lecturer performance comparison PDF (courses, sessions, students, attendance records per lecturer)
- `/api/admin/reports/students` — Admin: Student/employee analytics PDF (attendance rates, course enrollments, quiz averages per student)
- `/api/admin/reports/summary` — Admin: Full institution summary PDF (users, attendance, subscription, academics, check-in methods, last 30 days activity)
- `/api/payments` — Subscription management
- `/api/reports` — PDF report generation (attendance, sessions, performance)

### Data Models
- **User** — Supports email or indexNumber login, role-based, company-scoped, device tracking
- **Company** — Has mode (corporate/academic), subscription state, trial dates, auto-generated institutionCode, qrSeed (hex), bleLocationId
- **AttendanceSession** — Active/stopped sessions per company, locked to institution via qrSeed and bleLocationId
- **AttendanceRecord** — Per-user check-in records with method tracking
- **QrToken** — Time-limited tokens with 6-digit codes for attendance
- **StudentRoster** — Pre-registered student IDs per course, uploaded by lecturers. Used to validate student registration.
- **Course** — Academic courses with enrolled students
- **Quiz** — Quiz metadata: title, description, course, lecturer, timeLimit, totalMarks, startTime, endTime, institution-scoped
- **Question** — Separate model: questionText, options (string array), correctAnswer (index), marks. Linked to Quiz via quizId
- **Attempt** — Student quiz attempt: quiz, student, score, maxScore, startedAt, submittedAt, isSubmitted. Unique per quiz+student
- **Answer** — Individual answer records: attempt, question, selectedAnswer, isCorrect. Unique per attempt+question
- **ZoomMeeting** — Jitsi meetings with auto-generated room names/join URLs, attendee tracking (joinedAt, leftAt, status), company-scoped, linked to sessions/courses
- **JitsiMeeting** — Lightweight meeting record: roomName (companyId_sessionId_hash, immutable), companyId, sessionId, createdBy, startTime, endTime. No extra fields.
- **JitsiAttendance** — Join/leave tracking: userId, meetingId, action (join|leave), timestamp. Indexed by meetingId+userId.

### Dashboard Access Rules
- **Admin**: Manage subscription, approve lecturers/employees/students, view all attendance, see institution code/QR Seed/BLE Location ID
- **Lecturer**: Create classes/courses, generate QR codes, mark attendance, view reports
- **Student**: View attendance, scan QR, mark attendance — cannot create classes or sessions
- **Employee**: View own attendance, join meetings — requires admin approval

### Frontend
- Vanilla HTML/CSS/JS served from `src/public/`
- Single-page app pattern with portal selection (Admin Corporate, Admin Academic, Employee, Lecturer, Student)
- Communicates with backend via fetch API calls
- No build step required

## External Dependencies

### Database
- **MongoDB** — Primary data store, connected via `MONGODB_URI` environment variable. Uses Mongoose ODM with schemas, indexes, and TTL expiry.

### Environment Variables Required
- `MONGODB_URI` — MongoDB connection string
- `JWT_SECRET` — Secret for signing JWT tokens
- `JWT_EXPIRES_IN` — Token expiration (default: "7d")
- `PORT` — Server port (default: 5000)
- Stripe and Paystack API keys (for payment integration)

### Third-Party Services
- **Stripe** — Payment processing for USD subscriptions (webhook at `/api/payments/webhook/stripe`)
- **Paystack** — Payment processing for GHS subscriptions (webhook at `/api/payments/webhook/paystack`)
- **Zoom API** — Meeting creation (placeholder — integration pending, models and routes exist)
- **BLE (Bluetooth Low Energy)** — Client-side module for React Native mobile apps, not a server dependency

### NPM Packages
- `express` (v5) — Web framework
- `mongoose` (v9) — MongoDB ODM
- `bcryptjs` — Password hashing
- `jsonwebtoken` — JWT authentication
- `helmet` — HTTP security headers
- `cors` — Cross-origin resource sharing
- `dotenv` — Environment variable loading
- `pdfkit` — PDF report generation